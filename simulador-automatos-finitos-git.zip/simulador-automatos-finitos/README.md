# Simulador de Autômatos Finitos

Ferramenta em linha de comando que simula autômatos finitos (NFA sem epsilons).

## Arquivos principais
- `fa_simulator.py` — script CLI em Python 3.
- `examples/arquivo_do_automato.aut` — exemplo de autômato (JSON).
- `examples/arquivo_de_testes.in` — arquivo de testes (palavra;esperado).
- `examples/arquivo_de_saida.out` — exemplo de saída gerada.

## Uso
```bash
python3 fa_simulator.py arquivo_do_automato.aut arquivo_de_testes.in arquivo_de_saida.out
```

## Formatos
- `.aut` (JSON): chaves `initial` (int), `final` (lista ints), `transitions` (lista de objetos `{from, read, to}`).
- `.in` (CSV com `;`): cada linha `palavra;resultadoEsperado` (1 aceita, 0 rejeita).
- saída: `palavra;resultadoesperado;resultado_obtido;tempo_em_segundos`

## Exemplo rápido
```json
{
  "initial": 0,
  "final": [2],
  "transitions": [
    {"from": 0, "read": "a", "to": 1},
    {"from": 1, "read": "b", "to": 2},
    {"from": 2, "read": "a", "to": 2}
  ]
}
```
