#!/usr/bin/env python3
"""Simulador de Autômatos Finitos (NFA sem epsilons)
Uso: python3 fa_simulator.py automato.aut testes.in saida.out
"""
import sys
import json
import time
from typing import Dict, List, Set

def load_automaton(path: str):
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    initial = data.get('initial')
    finals = set(data.get('final', []))
    transitions_raw = data.get('transitions', [])
    trans = {}
    for t in transitions_raw:
        fr = t['from']
        sym = t['read']
        to = t['to']
        trans.setdefault(fr, {}).setdefault(sym, []).append(to)
    return initial, finals, trans

def load_tests(path: str):
    tests = []
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if ';' in line:
                word, expected = line.split(';', 1)
            else:
                word, expected = line, ''
            word = word.strip()
            expected = expected.strip()
            if expected == '':
                expected_val = None
            else:
                expected_val = 1 if expected in ('1', 'true', 'True') else 0
            tests.append((word, expected_val))
    return tests

def simulate_nfa(initial: int, finals: Set[int], trans: Dict[int, Dict[str, List[int]]], word: str) -> bool:
    if word == '':
        return initial in finals
    from collections import deque
    q = deque()
    q.append((initial, 0))
    visited = set()
    while q:
        state, idx = q.popleft()
        if (state, idx) in visited:
            continue
        visited.add((state, idx))
        if idx == len(word):
            if state in finals:
                return True
            else:
                continue
        sym = word[idx]
        nxts = trans.get(state, {}).get(sym, [])
        for n in nxts:
            q.append((n, idx+1))
    return False

def main():
    if len(sys.argv) != 4:
        print('Uso: python3 fa_simulator.py automato.aut testes.in saida.out')
        sys.exit(1)
    autom_path = sys.argv[1]
    tests_path = sys.argv[2]
    out_path = sys.argv[3]

    initial, finals, trans = load_automaton(autom_path)
    tests = load_tests(tests_path)

    with open(out_path, 'w', encoding='utf-8') as out:
        for word, expected in tests:
            t0 = time.perf_counter()
            accepted = simulate_nfa(initial, finals, trans, word)
            t1 = time.perf_counter()
            elapsed = t1 - t0
            obtained = 1 if accepted else 0
            exp_str = '' if expected is None else str(expected)
            out.write(f"{word};{exp_str};{obtained};{elapsed:.6f}\n")

if __name__ == '__main__':
    main()
